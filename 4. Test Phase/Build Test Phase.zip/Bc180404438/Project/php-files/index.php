<?php
echo "Welcome to Faculty Directory for Multi University";

?>