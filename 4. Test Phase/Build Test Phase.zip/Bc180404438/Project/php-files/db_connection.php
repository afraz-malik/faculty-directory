<?php
// database connection code
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');

$con = mysqli_connect('localhost', 'root', '','faculty');
//$con = mysqli_connect('sql6.freemysqlhosting.net', 'sql6427280', 'jxgnA7HHAQ','sql6427280');
?>
