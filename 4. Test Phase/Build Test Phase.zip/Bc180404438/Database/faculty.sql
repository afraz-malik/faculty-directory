-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 31, 2021 at 10:19 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faculty`
--
CREATE DATABASE IF NOT EXISTS `faculty` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `faculty`;

-- --------------------------------------------------------

--
-- Table structure for table `faculty_member`
--

CREATE TABLE `faculty_member` (
  `fm_id` int(11) NOT NULL,
  `fm_name` varchar(255) NOT NULL,
  `fm_address` varchar(255) NOT NULL,
  `fm_designation` varchar(255) NOT NULL,
  `fm_salary` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty_member`
--

INSERT INTO `faculty_member` (`fm_id`, `fm_name`, `fm_address`, `fm_designation`, `fm_salary`) VALUES
(41242462, 'Dr. Ferhana Ahmad', 'House no 13,street no 8,Awan town, Lahore', 'Assistant Professor in LUMS', 200000),
(134471741, 'Dr. Adam Zaman Chaudhry', 'house no 16, street no 01,tajpura. Lahore', 'Assistant Professor in LUMS', 130000),
(208902600, 'Dr. Zehra Waheed', 'house no 16, street no 01,North Karachi', 'Assistant Professor in LUMS', 134000),
(240561310, 'Ammar Hasan', 'Flat no 15,Rukshanda heights,Lahore', 'HOD POWER & CONTROL ENGINEERING IN NUST', 250000),
(253548374, 'Afraz Malik', '2/8 Malik Park, Amir Rd,Shad Bagh', 'Junior Programmar', 10000),
(254920144, 'Dr. Abdul Wahid', 'house no 16, street no 01,Peshawar', 'HOD NUST INSTITUTE OF INFORMATION TECHNOLOGY', 190000),
(317624049, 'Dr. Zubair Abbasi', 'house no 16, street no 01,wasanpura. Lahore', 'Associate Professor at the Shaikh Ahmad Hassan School of Law, Lahore University of Management Sciences (LUMS)', 100000),
(391729100, 'Ms. Naila Noureen', 'House no 21,near taj marquee . golbagh,Lahore', 'research scholar in Cancer Research Centre', 150000),
(631088028, 'Dr. Saira Zainab', 'House No 5,Street No 10,Rawalpindi', 'ASSOCIATE PROFESSOR IN NUST', 375000),
(637834780, 'Dr. Sania Zahra Malik', 'Hose no 10,Street no 7,Johar town, Lahore', 'Director in Punjab Univesrty', 500000),
(695570018, 'Ms. Hina Munir Butt', 'Hose no 07,Street No 3, RAWALPINDI', 'Assistant Professor in NUST', 138000),
(719947204, 'Dr. Ferhana Ahmad', 'House no 13,street no 8,Awan town, Lahore', 'Assistant Professor in LUMS', 200000),
(806873855, 'Khawar Khurshid', 'House no 20,Street No 9, golbagh,Islamabad', 'ASSOCIATE PROFESSOR IN NUST', 120000),
(937447505, 'Dr. Arshad Ahmad', 'House no 13,street no 13, Islamabd', 'Molson School of Business', 320000),
(971153907, 'Malik Moin Awan', 'House no 29,Saba Gali,Taj Bagh Scheme, Lahore', 'Custom Clearing Agent', 150000),
(1001125667, 'Dr. Muhammad Usman', 'House no 13,street no 17 ,faisal town, Lahore', 'Assistant Professor-Tenure Track in the Department of Mathematics - (SBASSE).', 174900),
(1081777806, 'Dr. Nasir Abbas', 'House no 13,street no 13 ,faisal town, Lahore', 'Director General of the Urdu Science Board, Lahore', 200000),
(1171782367, 'Mr. Hassan Emaduddin Ansari', 'House no 10,street no 3,Faisal town, Lahore', 'Assistant Professor in LUMS', 130001),
(1219669718, 'Dr. Muhammad Farooq Sabar', 'house no 16, street no 01,wasanpura. Lahore', 'CAMB', 76000),
(1277282124, 'Dr. Sadaf Ahmad', 'House no 11,street no 3,Iqbal town, Lahore', 'Associate Professor in LUMS', 130000),
(1306904948, 'Miss. Naumana Ayub', 'House no 14,street no 3,johar town, Lahore', 'Assistant Professor in NUST', 240000),
(1325037498, 'Dr. Hasan Tahir', 'House no 09,street no 1 ,faisal town, Lahore', 'HOD INTELLIGENT SYSTEM (IS) IN NUST', 315000),
(1328177806, 'Dr. Ammar Ahmed Khan', 'House no 21,harbanspura,Lahore', 'Associate Professor in LUMS', 70000),
(1393514544, 'Prof. Dr Jamshaid Ahmed', 'House no 16,street no 6,Wapda town, Lahore', 'Professor In UCP', 160000),
(1563671690, 'Dr. Arif Nazir Butt', 'House no 09,street no 6,johar town, Lahore', 'Professor at the Suleman Dawood School of Business at the Lahore University of Management Sciences, Lahore, Pakistan', 99000),
(1672357863, 'Dr. Ghazal Mir Zulfiqar', 'house no 16, street no 01,new Karachi', 'Associate Professor in LUMS', 212000),
(1768504953, 'Dr. Hasan Ali Khattak', 'House no 1,street no 12 ,islamabad', 'ASSOCIATE PROFESSOR IN NUST', 85000),
(1808442571, 'Dr. Muhammad Imran Malik', 'house no 29, street no 01,Lahore', 'Assistant Professor in NUST', 273000),
(1934180475, 'Dr. Usman Zabit', 'House no 18,street no 3,D-chowk,Islamabad', 'PROFESSOR IN NUST', 123000),
(1940409933, 'Rafia Mumtaz', 'House no 15,street no 4,Islamabad', 'ASSOCIATE PROFESSOR IN NUST', 178000),
(1957033755, 'Dr. Muhammad Abdur Rahman Malik', 'Flat no 115,ravi heights,Lahore', 'Associate Professor in LUMS', 175000),
(2083890674, 'Mr. Hashir Moheed Kiani', 'House no 2,Street No 4,Lahore', 'Assistant Professor in NUST', 180000),
(2095886060, 'Dr. Muhammad Ghufran Ahmad', 'House no 17,street no 7,johar town, Lahore', 'Associate Professor in LUMS', 212000);

-- --------------------------------------------------------

--
-- Table structure for table `qualification`
--

CREATE TABLE `qualification` (
  `q_id` int(11) NOT NULL,
  `fm_id` int(11) NOT NULL,
  `degree_tittle` varchar(255) NOT NULL,
  `year_of_passing` varchar(255) NOT NULL,
  `institute_attended` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qualification`
--

INSERT INTO `qualification` (`q_id`, `fm_id`, `degree_tittle`, `year_of_passing`, `institute_attended`) VALUES
(1, 971153907, 'Matriculation', '2016', 'LAHORE GRAMER SCHOOL'),
(3, 971153907, 'ICS', '2018', 'Govt Islamia College,Railway Road Lahore'),
(4, 971153907, 'BSCS', '2020', 'VIRTUAL UNIVERSTY'),
(7, 253548374, 'Matriculation', '2015', 'Jinnah Grammar School'),
(8, 253548374, 'ICS', '2017', 'Punjab Group of Colleges'),
(9, 253548374, 'BSCS', '2022', 'Virtual University Of Pakistan'),
(10, 637834780, 'PhD in Business Management', '2001', 'University of Glasgow, United Kingdom'),
(11, 637834780, 'IBA', '1998', 'MBA in Finance'),
(12, 391729100, 'PhD scholar', '2011', 'Cancer Biology Lab-MMG'),
(13, 1219669718, 'MPhil program', '1994', 'CAMB'),
(14, 937447505, 'PhD in Psychology', '2000', 'McGill University'),
(15, 937447505, 'MBA', '2004', 'McGill University'),
(16, 1081777806, 'Phd in Urdu', '1998', 'GC University Lahore'),
(17, 1081777806, 'M.phil', '2003', 'Punjab Universty'),
(18, 317624049, 'DPhil in Law', '1995', 'Oxford University'),
(19, 317624049, 'Judicial Islamization of  Laws', '2001', 'Punjab Universty'),
(20, 1957033755, 'Mechanical Engineering', '1998', 'UET Lahore'),
(21, 1957033755, 'Co-Faculty Lead', '2004', 'LUMS'),
(22, 41242462, 'DPhil in Mathematics', '2007', 'University of Oxford, England'),
(23, 41242462, 'MSc in Mathematical', '2000', 'University of Oxford, England'),
(24, 2095886060, 'Management Sciences', '2009', 'Lahore University of Management Sciences (LUMS)'),
(25, 2095886060, 'MBA in the career dynamics', '2012', 'Lahore University of Management Sciences (LUMS)'),
(26, 1328177806, 'PhD', '2004', 'University of Cambridge'),
(27, 1328177806, 'Master of Philosophy (M.Phil) degree in the Engineering Department', '2010', 'University of Cambridge'),
(28, 719947204, 'DPhil in Mathematics', '2007', 'University of Oxford, England'),
(29, 719947204, 'MSc in Mathematical and Computational Finance', '2000', 'University of Oxford, England'),
(30, 1277282124, 'PhD in Cultural Anthropology', '2006', 'Syracuse University'),
(31, 1277282124, 'M.Phil in Cultural Anthropology', '2010', 'GC University Lahore'),
(32, 1171782367, 'Master of Public Policy (MPP) degrees', '1999', 'University of Michigan Law School '),
(33, 1171782367, 'Law and History Fellowship', '2007', 'University of Michigan Law School '),
(34, 1563671690, 'Phd in Human Resource Management', '2000', 'GC University Lahore'),
(35, 1563671690, 'M.Phil in Human Resource Management', '2002', 'GC University Lahore'),
(36, 208902600, ' PhD., Facilities Management', '1994', 'Heriot-Watt University, Scotland'),
(37, 208902600, 'MSc., Construction Project Management', '2000', 'Heriot-Watt University, Scotland'),
(38, 208902600, 'MBA (Finance)', '2002', 'Institute of Business Administration (IBA-Karachi), Pakistan'),
(39, 1001125667, 'PhD in Mathematics', '2012', 'Imperial College London'),
(40, 1001125667, 'BSc in Mathematics', '2006', 'Kingâ€™s College London and COMSATS Institute of Information Technology'),
(41, 1001125667, ' MSc in Mathematics', '2008', 'Kingâ€™s College London and COMSATS Institute of Information Technology'),
(42, 1672357863, 'PhD in Public Policy', '1991', 'University of Massachusetts, Boston'),
(43, 1672357863, 'MSc in Development Finance', '1998', 'Univesrity of London, School of Oriental and African Studies (SOAS)'),
(44, 1672357863, 'MBA in Development Finance', '2004', ' Institute of Business Administration, Karachi.'),
(45, 134471741, 'PhD in Physics', '2013', 'National University of Singapore (NUS)'),
(46, 134471741, 'M.Phil in Physics', '2015', 'National University of Singapore (NUS)'),
(47, 240561310, 'Bachelors in Electrical Engineering', '2004', 'National University of Sciences and Technology'),
(48, 240561310, 'MS in Electrical Engineering', '2008', 'Imperial College London'),
(49, 240561310, 'PhD in Electrical Engineering', '2012', 'Imperial College London'),
(50, 254920144, ' BSc ((Communications))', '2006', 'University of Engineering and Technology Lahore'),
(51, 254920144, 'MS (CS)', '2004', 'The University of Agriculture, Peshawar'),
(52, 254920144, 'Ph.D. in Computer Science & Engineering', '2013', 'Kyungpook National University'),
(53, 1325037498, ' Software Engineering ', '2008', 'Bahria University'),
(54, 1325037498, 'MS Software Engineering', '2011', 'National University of Sciences and Technology'),
(55, 1325037498, 'Doctor of Philosophy in Computing and Electronics', '2017', 'University of Essex'),
(56, 1934180475, 'BSc Electrical Engineering', '2001', 'University of Engineering and Technology Taxila'),
(57, 1934180475, 'Master (MICROWAVES ELECTROMAGNETISM OPTO-ELECTRONICS)', '2006', 'Institut National Polytechnique de Toulouse'),
(58, 1934180475, 'PhD (OPTO-ELECTRONICS)', '2010', 'Institut National Polytechnique de Toulouse'),
(59, 1940409933, ' Bachelor of Engineering in Software Engineering ', '2004', 'Fatima Jinnah Women University'),
(60, 1940409933, ' MS in Software Engineering ', '2006', 'National University of Sciences and Technology'),
(61, 1940409933, 'PhD in Electronic Engineering (REMOTE SENSING AND SATELLITE IMAGE PROCESSIN)', '2010', 'University of Surrey'),
(62, 806873855, 'BE (COMPUTER SYSTEMS ENGINEERING)', '2003', 'National University of Sciences and Technology'),
(63, 806873855, 'MS (Electrical Engineering)', '2005', 'Michigan State University'),
(64, 806873855, 'PhD Electrical Engineering (BIOMEDICAL IMAGING)', '2010', 'Michigan State University'),
(65, 631088028, 'Matriculation (Science)', '1995', 'Board of Intermediate and Secondary Education, Rawalpindi'),
(66, 631088028, 'Intermediate (Humanities)', '1997', 'Board of Intermediate and Secondary Education, Rawalpindi'),
(67, 631088028, ' Bachelor of Science (Mathematics)', '1999', 'Associate Ordinary Bachelor'),
(68, 631088028, ' Master of Science (Mathematics)', '2008', 'COMSATS Institute of Information Technology'),
(69, 631088028, 'Doctor of Philosophy (Mathematics)', '2012', 'COMSATS Institute of Information Technology'),
(70, 1768504953, 'Ph.D. in Electrical and Computer Engineering (Semantic Web of Things)', '2014', 'Polytechnic Institute of Bari'),
(71, 695570018, 'Bechelor in Science (MATHEMATICS)', '2002', 'Azad Jammu and Kashmir University'),
(72, 695570018, ' Masters (MATHEMATICS)', '2005', 'Quaid-i-Azam University'),
(73, 695570018, 'Doctor of Philosophy (DIFFERENTIAL EQUATIONS)', '2016', 'National University of Sciences and Technology'),
(74, 1808442571, 'BS (Computer Sciences)', '2004', 'Allama Iqbal Open University'),
(75, 1808442571, 'M.Phil (Artificial Intelligence)', '2011', 'UniversitÃ¤t Kaiserslautern'),
(76, 1808442571, 'Doctor of Engineering (Machine Learning for Forensic Document Analysis)', '2015', 'UniversitÃ¤t Kaiserslautern'),
(77, 2083890674, 'Electrical Engineering (Telecommunication)', '2011', 'National University of Sciences and Technology'),
(78, 2083890674, 'MS (Communications Engineering and Networks)', '2013', 'University of Birmingham'),
(79, 2083890674, 'PhD (Computer Science)', '2020', 'University of Manchester'),
(80, 1306904948, 'BE Electrical (Telecommunication) Engineering (Telecommunication)', '2012', 'National University of Sciences and Technology'),
(81, 1306904948, ' MS in Electrical Engineering (Communication and Networks)', '2014', 'National University of Sciences and Technology'),
(82, 1306904948, 'PhD in Communications Engineering (Wireless Communication)', '2019', 'City University of London'),
(83, 1393514544, 'PhD', '2010', 'Hamdard University Karachi'),
(84, 1393514544, 'Post Graduate higher education teaching qualification', '2015', 'Hamdard University Karachi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `faculty_member`
--
ALTER TABLE `faculty_member`
  ADD PRIMARY KEY (`fm_id`);

--
-- Indexes for table `qualification`
--
ALTER TABLE `qualification`
  ADD PRIMARY KEY (`q_id`),
  ADD KEY `fm_id` (`fm_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `faculty_member`
--
ALTER TABLE `faculty_member`
  MODIFY `fm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2095886061;
--
-- AUTO_INCREMENT for table `qualification`
--
ALTER TABLE `qualification`
  MODIFY `q_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `qualification`
--
ALTER TABLE `qualification`
  ADD CONSTRAINT `qualification_ibfk_1` FOREIGN KEY (`fm_id`) REFERENCES `faculty_member` (`fm_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
